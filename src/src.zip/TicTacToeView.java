public interface TicTacToeView {
    void handleTicTacToeUpdate(TicTacToeEvent e);
}